//package xmu.oomall.domain;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import xmu.oomall.dao.CommentDao;
//import static org.junit.jupiter.api.Assertions.*;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.List;
//
//@SpringBootTest(classes = CommentTest.class)
//public class CommentTest {
//    @Autowired
//    private CommentDao dao;
//
//    private Comment cmnt;
//
////    private List<Comment> goodsList = new ArrayList<>();
//    private List<Integer> numList = new ArrayList<>();
//
//    @BeforeEach
//    public void before() {
//        cmnt = dao.findCommentById(0);
//
//
//
//    }
//
//    @Test
//    public void cacuFeeTest() {
//        BigDecimal fee = cmnt.cacuFee(goodsList, numList);
//
//    }
//}
